import React from 'react'
import { MdSettingsSuggest } from 'react-icons/md'
import {  IoLogoYahoo } from 'react-icons/io'
import { FaBuilding, FaBusinessTime, FaRegLightbulb, FaWater } from 'react-icons/fa'
import { RxGear } from 'react-icons/rx'
import { FaWandMagicSparkles } from "react-icons/fa6";
import Services_Page_Tabs from '../Services/Pages/Services_Page_Tabs/Services_Page_Tabs'
import ALL_Submenu_contact from '../Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact'
import PROJECTS_MANAGEMENT_para from '../Services/Pages/ELECTRICAL_SYSTEMS/PROJECTS_MANAGEMENT_para/PROJECTS_MANAGEMENT_para'
import Card_Reuse from '../Services/Pages/ELECTRICAL_SYSTEMS/Card_Reuse/Card_Reuse'

export default function MECHANICAL_SYSTEMS_STYLE() {
  return (
    <div>
<div className='flex'>
<div className='hidden md:block'> 
       <Services_Page_Tabs />
       <ALL_Submenu_contact/>

</div>

<div>
      <PROJECTS_MANAGEMENT_para
      title=""
      content="Niebogran Trading & Contracting excels in executing mechanical works by thoroughly studying market and project requirements. We focus on designing and delivering well-researched engineering solutions that meet the highest standards of accuracy and completeness."
      content2="Our mechanical systems are implemented in full compliance with both Qatar's standards and international standards, ensuring maximum quality and safety in every project we undertake."
      imageUrl="/Mechanical_Systems.png"  
      imageAlt="MECHANICAL_SYSTEMS_Image"
      />
      
    
     <div className="grid  sm:grid-cols-1 md:grid-cols-4 gap-4 p-4">
           <Card_Reuse id="01" title="Heating, Ventilation and HVAC" icon={<FaBusinessTime  size={28} />} />
           <Card_Reuse id="02" title="Plumbing and Piping" icon={<FaBuilding size={28} />} />
           <Card_Reuse id="03" title="Drainage and Sewage" icon={<FaWandMagicSparkles size={28} />} />
           <Card_Reuse id="04" title="Fire Protection Systems" icon={<FaRegLightbulb size={28} />} />
           <Card_Reuse id="05" title="Garbage and Wastage Systems" icon={<FaBusinessTime size={28} />} />
           <Card_Reuse id="06" title="External Mechanical Network" icon={<MdSettingsSuggest size={28} />} />
         </div>
         </div>
      
         </div> 
    </div>
  )
}
