import React from 'react'
import Services_Page_Tabs from '../Services/Pages/Services_Page_Tabs/Services_Page_Tabs'
import ALL_Submenu_contact from '../Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact'
import PROJECTS_MANAGEMENT_para from '../Services/Pages/ELECTRICAL_SYSTEMS/PROJECTS_MANAGEMENT_para/PROJECTS_MANAGEMENT_para'

export default function METAL_BARRIERSSTYLEl() {
  return (
    <div>

<div className='flex'> 
<div className='hidden md:block'>
       <Services_Page_Tabs />
       <ALL_Submenu_contact/>
       </div>

      <PROJECTS_MANAGEMENT_para
      title=""
      content="Niebogran Trading & Contracting specializes in the execution of metal barriers by thoroughly analyzing market and project requirements. We focus on designing and delivering specialized engineering solutions, ensuring the highest levels of accuracy and precision."
      content2="Our work adheres strictly to Qatar's standards and international benchmarks, guaranteeing maximum quality and safety in all external network projects involving metal barriers. Niebogran is committed to excellence in every project, delivering durable and reliable solutions tailored to our clients' needs."
      imageUrl="/Metal_Barriers.png"  
      imageAlt="METAL BARRIERS Image"
      />
     </div> 

      
      
    </div>
  )
}
