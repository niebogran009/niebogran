import Image from 'next/image';
import Link from 'next/link';
import React, { useState, useEffect } from 'react';
import { FaSearch, FaStar } from 'react-icons/fa';

export default function Projects_main_style() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const mockProducts = [
      { id: 1, name: 'Fence and Security', Link: "/page/about_us", image: '/Fence_Security_Barriers.png' },
      { id: 2, name: 'Electrical Works', Link: "/Electrical_Works", image: '/Electrical_Works.png' },
      { id: 3, name: 'Constructions', Link: "/Constructions", image: '/Constructions.png' },
      { id: 4, name: 'Fiber Optics', Link: "/Fiber_Optic", image: '/Fiber_Optic.png' },
    ];

    setProducts(mockProducts);
  }, []);

  return (
    <div className="container mx-auto p-6">
      {/* Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {products.map((product) => (
          <div key={product.id} className="border rounded-lg shadow-lg bg-white text-center">
            <Image
              src={product.image}  // Use the correct path to the image
              alt={product.name}
              width={400}  // Set a fixed width
              height={250} // Set a fixed height
              className="w-full h-64 object-cover rounded-t-lg"
            />
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
              <Link href={product.Link}>
                <span className="bg-primary text-sm p-2 px-3 hover:bg-red-900 text-white rounded-lg font-bold">
                  More Details
                </span>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
