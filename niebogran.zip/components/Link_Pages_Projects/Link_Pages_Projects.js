import Link from 'next/link';
import React from 'react'

export default function Link_Pages_Projects() {
  const services = [
    { id: 1, name: "Constructions", link: "/Page/Projects/pages/Constructions" },
    { id: 2, name: "Fiber Optic", link: "/Page/Projects/pages/Fiber_Optic" },
    { id: 3, name: "Fence & Security Barriers", link: "/Page/Projects/pages/Fence_Security_Barriers" },
    { id: 4, name: "Electrical Works", link: "/Page/Projects/pages/Electrical_Works" },
  ];
  
  return (
    <div>
         <div className="flex px-4  mb-5  pt-10">
              <section className="bg-gray-50 p-8 rounded-xl shadow-lg sm:w-full md:w-[400px]">
                {/* Title */}
                <div className="text-3xl font-extrabold mb-6 text-gray-800 border-b-2 border-red-500 inline-block pb-2">
                Our Projects
                </div>
      
                {/* Services List */}
                <ul className="space-y-6 pl-6 border-l-4 border-gray-300">
                  {services.map((service) => (
                    <li key={service.id} className="relative group">
                      <Link href={service.link}>
                      <span
                        
                        className="block text-lg text-gray-700 font-semibold hover:text-red-600 transition-all duration-300"
                      >
                        <span className="relative">
                          {service.name}
                          {/* Arrow Effect */}
                          <span className="absolute left-[-28px] top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300 text-red-500 text-2xl">
                            &rarr;
                          </span>
                        </span>
                      </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </section>
            </div>
    </div>
  )
};
