import React from 'react';
import { FaHandHoldingWater, FaWater, FaRoad, FaPlug, FaCar, FaBuilding, FaCogs, FaSignal } from 'react-icons/fa';

const CardItem = ({ number, title, Icon }) => (
  <div className="flex flex-col items-center text-center bg-gray-100 p-6 rounded-lg shadow-lg">
    <span className="text-icon bg-red-600 hover:bg-red-700 rounded-full p-2 mb-4">
      <span className="icon-inner text-white text-2xl transition-transform transform hover:scale-110">
        <Icon />
      </span>
    </span>
    <h4 className="text-xl font-bold text-primary mb-2">{number}</h4>
    <div className="text-lg font-semibold text-gray-700">{title}</div>
  </div>
);

export default function Card() {
  const cardDetails = [
    { number: '01', title: 'Water and Sanitation', Icon: FaHandHoldingWater },
    { number: '02', title: 'Dams Works', Icon: FaWater },
    { number: '03', title: 'Road Maintenance', Icon: FaRoad },
    { number: '04', title: 'Electrical Works', Icon: FaPlug },
    { number: '05', title: 'Roads Works', Icon: FaCar },
    { number: '06', title: 'Buildings', Icon: FaBuilding },
    { number: '07', title: 'Mechanical Business', Icon: FaCogs },
    { number: '08', title: 'Communication Technology', Icon: FaSignal },
  ];

  return (
    <div>
      <div className="flex flex-wrap justify-center py-6 text-primary">
        {cardDetails.map(({ number, title, Icon }, index) => (
          <div key={index} className="w-full sm:w-1/2 md:w-1/3 lg:w-1/4 p-4">
            {/* Responsive classes to adjust the number of cards per row */}
            <CardItem number={number} title={title} Icon={Icon} />
          </div>
        ))}
      </div>
    </div>
  );
}
