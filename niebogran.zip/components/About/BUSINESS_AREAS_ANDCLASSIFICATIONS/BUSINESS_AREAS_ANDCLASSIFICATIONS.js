import React from 'react'
import { FaDotCircle } from "react-icons/fa";
import Card from './Card';

export default function BUSINESS_AREAS_ANDCLASSIFICATIONS() {
  return (
    <div className="px-4 sm:px-8 md:px-16">
      <div className="mb-5">
        <h1 className="text-center text-primary text-lg font-bold">BUSINESS AREAS AND CLASSIFICATIONS</h1>
        <div className="flex justify-center">
          <div className="text-red-700 flex text-xl">
            <span className="text-primary">______________</span>
            <FaDotCircle className="mt-3" />
            <span className="text-primary">______________</span>
          </div>
        </div>
      </div>

      <p className="text-center text-primary px-4 sm:px-8 md:px-32">
        Niebogran  was established in 1990 and has completed more than 500 projects in different fields, mostly within government sectors.
        Niebogran  is classified in (9) areas by Saudi contractor’s classification code.
      </p>

      <div className="mt-8">
       <Card/>
      </div>
    </div>
  );
}
