import React from 'react';
import Image from 'next/image';

const Message_From_CEO = () => {
    return (
        <div className="flex flex-wrap justify-between sm:px-4 sm:px-10 my-10">
            {/* Left Column */}
            <div className="w-full sm:w-[39%] bg-gray-100 p-5">
                <div className="text-left">
                    <h2 className="font-bold text-2xl mb-2">Message From CEO</h2>
                    <div className="flex items-center gap-2 mb-4">
                        <div className="text-red-600 text-lg">
                            <i className="fas fa-circle"></i> {/* Updated to 'fas' for solid icon */}
                        </div>
                        <div className="flex-grow h-px bg-gray-700"></div>
                    </div>
                    {/* 1 */}
                    <p className="text-primary mb-4">
                        <strong>Niebogran</strong> Trading & Contracting was established over thirty years ago and has since become renowned for its proficiency, success, and accomplishments in over 500 projects. These achievements result from the dedication of our exceptional technical and managerial teams, along with their accumulated experience and unwavering commitment to fostering strong internal and external relationships.
                    </p>
                    {/* 2 */}
                    <p className="text-primary mb-4">
                        <strong>Niebogran</strong> has collaborated on major projects with long-standing partners across government, private, and semi-government sectors. We remain steadfast in achieving even greater success, building trust, and forming new partnerships while strengthening existing ones. I take this opportunity to extend my heartfelt gratitude to all our strategic partners for enabling us to grow and succeed together for a prosperous future.
                    </p>
                    {/* 3 */}
                    <p className="text-primary mb-4">
                        <strong>Niebogran</strong>Trading & Contracting was established in 2018 and has successfully completed over 450 projects across various fields,
                    </p>
                    {/* 4 */}
                    <p className="text-primary">
                        <strong>Niebogran</strong>is classified in nine distinct areas under Qatar contractor classification system.
                    </p>
                </div>
            </div>

            {/* Right Column */}
            <div className="w-full sm:w-[58%] flex justify-center items-center">
                <figure className="w-full bg-gray-100 p-6">
                    <Image
                        src="/About_part_2.webp"
                        alt="Al-Dafe Company Profile"
                        className="w-full h-auto object-cover border border-gray-300 rounded-lg"
                        width={1000}
                        height={500}
                    />
                </figure>
            </div>
        </div>
    );
};

export default Message_From_CEO;
