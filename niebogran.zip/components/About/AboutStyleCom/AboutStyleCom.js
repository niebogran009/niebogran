import React, { useEffect, useState } from "react";

const AboutStyleCom = ({ title }) => {
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true); // Set animation to true when element comes into view
        }
      },
      {
        threshold: 0.5, // Trigger when 50% of the element is visible
      }
    );

    const element = document.getElementById("parallax-text");
    if (element) {
      observer.observe(element);
    }

    return () => {
      if (element) {
        observer.unobserve(element);
      }
    };
  }, []);

  return (
    <div>
      {/* Parallax Section */}
      <div
        className="parallax bg-fixed bg-center bg-cover bg-no-repeat h-[60vh] w-full"
        style={{
          backgroundImage: `url('/carasole_img_res.webp')`,
        }}
      >
        {/* Overlay for better visibility */}
        <div className="bg-black bg-opacity-50 h-full flex justify-center items-center">
          <h1
            id="parallax-text"
            className={`text-white text-4xl font-bold ${
              isInView ? "animate-slide-up" : ""
            }`}
          >
            {title}
          </h1>
        </div>
      </div>
    </div>
  );
};

export default AboutStyleCom;
