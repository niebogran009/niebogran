import React from 'react'
import Link_Pages_Projects from '../Link_Pages_Projects/Link_Pages_Projects';
import ALL_Submenu_contact from '../Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact';
import Constructions_style_image from '../PROJECTS/Constructions_style_image/Constructions_style_image';
import Project_name_card_red from '../PROJECTS/Project_name_card_red/Project_name_card_red';


export default function Fiber_Optic_style() {
    const cardData = [
        // Red Cards
        {
          bgColor: "bg-[#c52129]",
          title: "Project Name",
          description: "Fiber Optic Extension Project.",
          amount: "####",
        },
        {
          bgColor: "bg-[#c52129]",
          title: "Project Name",
          description: "Extending a Fiber Optic Networ Project in the Southern Border Regions.",
          amount: "####",
        },
      ];

  return (
    <div>
        <div className='flex'>

        <div className='hidden md:block'>
        <Link_Pages_Projects />
          <ALL_Submenu_contact />
          </div>
      
      <div>
<Constructions_style_image
    largeSrc="/Fiber_Optic.png"
    largeAlt="Large construction image"
/>

<div className="">
      <Project_name_card_red data={cardData} />
    </div>

      </div>



          </div>
    </div>
  )
}
