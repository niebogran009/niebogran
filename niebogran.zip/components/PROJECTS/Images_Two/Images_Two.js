import Image from 'next/image'
import React from 'react'

export default function Images_Two({ 
  
    smallSrc1, smallAlt1, 
    smallSrc2, smallAlt2 ,
    
  })
{
  return (
    <div>
       {/* Flex container for smaller images */}
       <div className='flex flex-wrap justify-center md:mt-10 sm:mt-0'>
        
        {/* Image 1 */}
        <div className='md:py-10 sm:py-0 md:w-1/2 px-5'>
          <Image 
            src={smallSrc1}
            width={500}
            height={500}
            alt={smallAlt1}
          />
        </div>

        {/* Image 2 */}
        <div className='md:py-10 sm:py-0 md:w-1/2 px-5'>
          <Image 
            src={smallSrc2}
            width={500}
            height={500}
            alt={smallAlt2}
          />
        </div>


        



      </div>
    </div>
  )
}