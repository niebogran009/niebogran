import Image from 'next/image'
import React from 'react'

export default function Constructions_style_image({ 
  largeSrc, largeAlt
  
}) {
  return (
    <div className=''>
      {/* Large Image */}
      <div className='md:mt-10 sm:mt-0'>
        <Image 
          src={largeSrc}
          width={1050}
          height={1050}
          alt={largeAlt}
          className='sm:w-full md:w-[1050px]'
        />
      </div>

     
    </div>
  )
}
