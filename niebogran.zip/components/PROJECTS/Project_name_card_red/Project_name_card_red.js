import React from 'react';

// Reusable Card component
const Card = ({ bgColor, title, description, entity, amount }) => {
    return (
        <div className='p-5'>
        <div className="min-h-[100px]   shadow-md ">
            <div className={`${bgColor} h-24 p-4  text-center`}>
                <h3 className="font-bold text-lg text-white">{title}</h3>
                <h5 className="font-normal text-base text-white">{description}</h5>
            </div>
            <div className="p-4 bg-white ">
                <ul className="space-y-2 text-center">
                    <li className="text-left text-gray-700">
                        <strong>Total Amount:</strong> <br /> {amount}
                    </li>
                </ul>
            </div>
        </div>
        </div>
    );
};

const Project_name_card_red = ({ data }) => {
    return (
        <div className="grid  sm:grid-cols-1 lg:grid-cols-3 gap-5">
            {data.map((card, index) => (
                <Card
                    key={index}
                    bgColor={card.bgColor}
                    title={card.title}
                    description={card.description}
                    amount={card.amount}
                />
            ))}
        </div>
    );
};

export default Project_name_card_red;
