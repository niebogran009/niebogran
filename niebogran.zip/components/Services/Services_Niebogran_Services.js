import React from "react";
import { FaDotCircle, FaProjectDiagram, FaBolt, FaCogs, FaRoad, FaHammer } from "react-icons/fa";
import Link from "next/link";

// Card Component
const Card = ({ icon: Icon, title, description, link }) => {
  return (
    <div className="w-[370px] p-6 bg-gray-100 text-primary rounded-lg shadow-lg hover:shadow-2xl transition transform hover:-translate-y-1">
      <div className="flex flex-col items-center text-center">
        {/* Icon */}
        <span className="w-14 h-14 bg-primary text-white rounded-full flex items-center justify-center mb-4 hover:bg-red-900 hover:text-white transition">
          <Icon size={28} />
        </span>

        {/* Title */}
        <h4 className="text-lg font-bold text-primary mb-2  transition">
          <Link href={link} title={title}>
          <span >
          {title}
          </span>
          </Link>
        </h4>

        {/* Description */}
        <p className="text-primary mb-5">{description}</p>

        {/* Button */}
        <a
          href={link}
          className="inline-block px-5 py-2 text-white bg-primary rounded-md hover:bg-red-900 transition"
        >
          More Details
        </a>
      </div>
    </div>
  );
};

// Roads Works Card Component
const RoadsWorksCard = ({ title, description, link, icon: Icon }) => {
  return (
    <div className="w-[500px] p-6 text-gray-100 text-center  rounded-lg shadow-lg hover:bg-gray-200 transition-all">
      <div className="text-center mb-4">
        <span className="flex justify-center">
          {/* Using the passed icon */}
          <Icon size={28} className="w-14 h-14 text-center  bg-primary text-white rounded-full flex items-center justify-center  hover:bg-red-900 hover:text-white transition" />
        </span>
      </div>
      <h4 className="text-xl font-semibold ">
        <a className="text-primary hover:text-primary" href={link} title={title}>
          {title}
        </a>
      </h4>
      <div className="text-gray-600 mb-4 text-center" dangerouslySetInnerHTML={{ __html: description }} />
      <a
        href={link}
        className="inline-block px-6 py-2 bg-primary text-white rounded-md hover:bg-red-900 transition-colors"
      >
        More Details
      </a>
    </div>
  );
};

// Main Component
const Services_Niebogran_Services = () => {
  const cardData = [
    {
      icon: FaProjectDiagram,
      title: "Project Management",
      description:
        "Niebogran Trading & Contracting Company is a highly qualified and professional",
      link: "/page/Services/Pages/PROJECTS_MANAGEMENT",
    },
    {
      icon: FaBolt,
      title: "Electrical Systems",
      description:
        "Our Engineers are specialized, Trained and experienced installation and maintenance",
      link: "/page/Services/Pages/ELECTRICAL_SYSTEMS",
    },
    {
      icon: FaCogs,
      title: "Mechanical System",
      description:
        "Niebogran Trading & Contracting Company is a highly qualified and professional",
      link: "/page/Services/Pages/MECHANICAL_SYSTEMS",
    },
  ];

  return (
    <div className="bg-gray-50 py-10">
      {/* Section Title */}
      <div className="my-5">
        <h1 className="text-center text-primary text-2xl font-bold">
        Niebogran  Services
        </h1>
        <div className="flex justify-center my-4">
          <div className="text-primary flex text-xl">
            <span className="text-primary">__________</span>
            <FaDotCircle className="mx-3 text-red-900" />
            <span className="text-primary">__________</span>
          </div>
        </div>
      </div>

      {/* Cards Grid */}
      <div className="flex flex-wrap justify-center gap-6 px-4">
        {/* Card Components */}
        {cardData.map((card, index) => (
          <Card
            key={index}
            icon={card.icon}
            title={card.title}
            description={card.description}
            link={card.link}
          />
        ))}
        
        {/* First Roads Works Card */}
        <RoadsWorksCard
          title="Roads Works"
          description="Al - Dafe Company is known for its quality works in the field of road works, as a result of"
          link="/page/Services/Pages/ROADS_WORK"
          icon={FaRoad} // FaRoad Icon for first card
        />

        {/* Second Roads Works Card */}
        <RoadsWorksCard
          title="Metal Barriers"
          description="Execution of Metal barriers through studying the requirements of the market and <br/> projects"
          link="/page/Services/Pages/METAL_BARRIERS"
          icon={FaHammer} // FaHammer Icon for second card
        />
      </div>
    </div>
  );
};

export default Services_Niebogran_Services;
