import Link from 'next/link';
import React from 'react';

export default function Services_Page_Tabs() {
  const services = [
    { id: 1, name: "Projects Management", link: "/Page/services/PROJECTS_MANAGEMENT" },
    { id: 2, name: "Electrical Systems", link: "/Page/services/ELECTRICAL_SYSTEMS" },
    { id: 3, name: "Mechanical Systems", link: "/page/Services/Pages/MECHANICAL_SYSTEMS" }, //ys page sahi hai 
    { id: 4, name: "Roads Works", link: "/Page/services/ROADS_WORK" },
    { id: 5, name: "Metal Barriers", link: "/Page/services/METAL_BARRIERS" },
  ];

  return (
    <div>
      <div className="flex px-4 sm:px-10 md:px-20 pt-10">
        <section className="bg-gray-50 p-8 rounded-xl shadow-lg sm:w-full md:w-[400px]">
          {/* Title */}
          <div className="text-3xl font-extrabold mb-6 text-primary border-b-2 border-red-500 inline-block pb-2">
            Our Services
          </div>

          {/* Services List */}
          <ul className="space-y-6 pl-6 border-l-4 border-gray-300">
            {services.map((service) => (
              // Ensure that the link is defined before rendering the Link component
              service.link ? (
                <li key={service.id} className="relative group">
                  <Link href={service.link}>
                    <span className="block text-lg text-primary font-semibold hover:text-red-600 transition-all duration-300">
                      <span className="relative">
                        {service.name}
                        {/* Arrow Effect */}
                        <span className="absolute left-[-28px] top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300 text-red-500 text-2xl">
                          &rarr;
                        </span>
                      </span>
                    </span>
                  </Link>
                </li>
              ) : (
                <li key={service.id} className="text-primary">Link is missing for {service.name}</li>
              )
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
