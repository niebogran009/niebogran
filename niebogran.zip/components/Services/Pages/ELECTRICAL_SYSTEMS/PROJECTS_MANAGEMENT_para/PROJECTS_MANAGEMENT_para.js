import Image from 'next/image';
import React from 'react';

// Main Component
export default function PROJECTS_MANAGEMENT_para({ title, content, content2, imageUrl, imageAlt }) {
  return (
    <div className="  grid  sm:grid-cols-1 w-full  md:grid-cols-1 sm:px-4  lg:px-10 xl:px-20 mt-9">
    <section className="p-6 bg-gray-50 text-gray-800 rounded-lg shadow-md max-w-5xl mx mx-auto animate-fadeInLeft">
      <div className="mb-4 text-primary">
        <h2 className="font-semibold text-primary text-xl mb-3">{title}</h2>
        <p className="text-justify text-primary leading-relaxed text-lg">
          {content}
        </p>
        <p className="text-justify text-primary leading-relaxed text-lg mt-4">
          {content2}
        </p>
      </div>
    </section>

    {/* Image Section */}
    <div className="relative w-full max-w-5xl mx-auto overflow-hidden rounded-lg shadow-lg mt-8">
      <Image
        src={imageUrl}
        alt={imageAlt}
        width={500}
        height={500}
        className="object-cover w-full h-auto rounded-lg shadow-lg"
      />
    </div>
  </div>
  );
}
