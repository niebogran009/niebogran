import React from 'react'

export default function Card_Reuse( {id,icon ,title}) {
  return (
    <div><div className=" ">
      <div className="flex flex-col items-center p-6 border h-[260px] rounded-lg shadow-lg hover:shadow-2xl transition-all duration-300 ease-in-out transform hover:scale-105">
        <span className="bg-red-900 hover:bg-primary p-6  text-white rounded-full transition-all duration-200 ease-in-out">
          {icon} 
        </span>
        <h4 className="text-2xl font-semibold mt-4 text-center text-primary">{id}</h4>
        <div className="text-center text-primary font-bold mt-2">{title}</div>
      </div>
  </div>
      
    </div>
  )
}
