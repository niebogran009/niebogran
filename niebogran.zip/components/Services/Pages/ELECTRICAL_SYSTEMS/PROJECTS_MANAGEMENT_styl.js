import React from 'react';

// Correct imports for icons
import { IoIosLock } from 'react-icons/io'; // Lock icon
import { FaBuilding, FaRegLightbulb, FaWater } from 'react-icons/fa'; // FontAwesome icons
import { SlEnergy } from 'react-icons/sl'; // Simple Line Icons
import { RxGear } from 'react-icons/rx'; // Radix Icons
import { IoLogoYahoo } from "react-icons/io";
import { MdSettingsSuggest } from 'react-icons/md'; // Material Design Icons
import ALL_Submenu_contact from './ALL_Submenu_contact/ALL_Submenu_contact';
import Card_Reuse from './Card_Reuse/Card_Reuse';
import PROJECTS_MANAGEMENT_para from './PROJECTS_MANAGEMENT_para/PROJECTS_MANAGEMENT_para';
import Services_Page_Tabs from '../Services_Page_Tabs/Services_Page_Tabs';

export default function PROJECTS_MANAGEMENT_styl() {
  return (
    <div>
<div className="flex">
  
<div className="hidden md:block">
  <Services_Page_Tabs />
  <ALL_Submenu_contact />
</div>

<div>
      <PROJECTS_MANAGEMENT_para
        title=""
        content="Niebogran Trading & Contracting specializes in the installation and maintenance of electrical systems. Our engineers are highly trained, experienced, and skilled in handling complex projects, ensuring compliance with specifications and industry codes."
        content2="We take pride in our experienced engineers and highly skilled technicians, who are thoroughly trained in electrical circuits to guarantee safety, reliability, and exceptional performance. At Niebogran, we are committed to meeting our customers' demands and delivering tailored solutions for every project."
        imageUrl="/Electrical_Systems.png"
        imageAlt="Niebogran  Company Profile"
      />
      <div className="grid  sm:grid-cols-1 md:grid-cols-4 gap-4 p-4">
        <Card_Reuse id="01" title="Alarm and Security Systems" icon={<IoIosLock size={28} />} />
        <Card_Reuse id="02" title="Building Management" icon={<FaBuilding size={28} />} />
        <Card_Reuse id="03" title="Energy Conservation" icon={<SlEnergy size={28} />} />
        <Card_Reuse id="04" title="Lighting" icon={<FaRegLightbulb size={28} />} />
        <Card_Reuse id="05" title="Motors and Generators" icon={<RxGear size={28} />} />
        <Card_Reuse id="06" title="Low Current/Medium Voltage" icon={<FaWater size={28} />} />
        <Card_Reuse id="07" title="External Electrical Networks" icon={<IoLogoYahoo  size={28} />} />
        <Card_Reuse id="08" title="Power Transmission and Distribution" icon={<MdSettingsSuggest size={28} />} />
      </div>
      </div>
      </div>

    </div>
  );
}
