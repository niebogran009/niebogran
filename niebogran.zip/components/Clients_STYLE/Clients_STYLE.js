import React, { useEffect, useState } from 'react';
import Image from 'next/image';

export default function Clients_STYLE() {
  const [mockProducts] = useState([
    { id: 1, image: '/clients/clients01.webp' },
    { id: 2, image: '/clients/clients02.webp' },
    { id: 4, image: '/clients/clients04.webp' },
    { id: 5, image: '/clients/clients05.webp' },
    { id: 6, image: '/clients/clients06.webp' },
    { id: 9, image: '/clients/clients09.webp' },
    { id: 10, image: '/clients/clients10.webp' },
    { id: 11, image: '/clients/clients11.webp' },
    { id: 12, image: '/clients/clients12.webp' },
    { id: 14, image: '/clients/clients14.webp' },
    { id: 15, image: '/clients/clients15.webp' },
  ]);

  return (
    <div
      className="mx-auto py-6 relative flex flex-col items-center bg-primary"
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 px-4">
        {mockProducts.map((product) => (
          <div key={product.id} className="flex justify-center items-center transition-transform ease-in-out duration-200 hover:scale-105">
            <Image
              src={product.image}
              alt={`Product ${product.id}`}
              width={160}
              height={160}
              className="w-52 h-52 object-cover rounded-lg mb-4 "
            />
          </div>
        ))}
      </div>
    </div>
  );
}
