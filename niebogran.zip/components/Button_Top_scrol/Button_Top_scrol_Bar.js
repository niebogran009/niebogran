import React, { useState, useEffect } from 'react';
import { FaAnglesUp } from "react-icons/fa6";

export default function Button_Top_scrol_Bar() {
  // State to track visibility of the button
  const [isVisible, setIsVisible] = useState(false);

  // Scroll event listener to show/hide the button
  useEffect(() => {
    const handleScroll = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true); // Show button if scroll position is greater than 300px
      } else {
        setIsVisible(false); // Hide button if scroll position is less than 300px
      }
    };

    window.addEventListener('scroll', handleScroll); // Add scroll event listener

    return () => {
      window.removeEventListener('scroll', handleScroll); // Clean up event listener on component unmount
    };
  }, []); // Empty dependency array ensures the effect runs once

  // Scroll to top function
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth', // Smooth scroll to the top
    });
  };

  return (
    isVisible && (
      <button
        onClick={scrollToTop} // Call scrollToTop function when clicked
        className="fixed bottom-28  md:bottom-16 right-2 md:right-10   bg-red-900 text-white p-4 rounded-full shadow-lg hover:bg-primary transition z-50  "
      >
        <FaAnglesUp />
      </button>
    )
  );
}
