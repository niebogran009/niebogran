import React from "react";
import Slider from "react-slick";
import Image from "next/image";
import Link from "next/link";
import { FaChevronLeft, FaChevronRight } from "react-icons/fa";

// Import Slick carousel CSS
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const Carousel_Image = () => {
  // Slick slider settings
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    pauseOnHover: true,
  };

  // Shared arrow style class
  const arrowClass =
    "absolute top-1/2 transform -translate-y-1/2 cursor-pointer text-red-500 hover:text-red-700";



  function PrevArrow(props) {
    const { onClick } = props;
    return (
      <div
        className={`${arrowClass} left-4`}
        onClick={onClick}
      >
        <FaChevronLeft size={30} />
      </div>
    );
  }

  // Carousel data
  const carouselItems = [
    {
      image: "/carasole_img_res.webp",
      heading: "Heading You To <br/> Build Your Future",
      description: "",
      link: "#services", // Update this with correct section id
      buttonText: "Services",
    },
    {
      image: "/carasole_img.webp",
      heading: "We Have An Enormous <br/> Experience With",
      description: "DIFFERENT SIZABLE PROJECTS",
      link: "#projects", // Update this with correct section id
      buttonText: "Projects",
    },
    {
      image: "/carasole_img3.webp",
      heading: "We Have An Awesome <br/> Highly Skilled Team",
      description: "",
      link: "/about", // Updated to correct path
      buttonText: "About Us",
    },
  ];

  return (
    <div className="relative w-full overflow-hidden">
      <Slider {...settings}>
        {carouselItems.map((item, index) => (
          <div key={index} className="carousel-item relative w-full h-[75vh]">
            {/* Optimized Image */}
            <Image
              src={item.image}
              alt={`Slide ${index + 1}`}
              layout="fill"
              objectFit="cover"
              className="w-full h-full"
            />
            {/* Overlay */}
            <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col justify-center items-center text-center text-white">
              <h1
                className="text-2xl sm:text-5xl font-bold mb-4 animate-slide-up"
                dangerouslySetInnerHTML={{ __html: item.heading }}
              />
              {item.description && (
                <p className="text-lg sm:text-xl mb-6 font-bold animate-slide-up-delay mt-5">
                  {item.description}
                </p>
              )}
              <div className="flex justify-center gap-6 mt-20">
                {/* Dynamic Link */}
                <Link href={item.link}>
                  <span className="bg-primary text-white px-6 py-2 sm:px-8 sm:py-3 rounded-lg hover:bg-red-900 font-bold transition duration-300 animate-button">
                    {item.buttonText}
                  </span>
                </Link>
                {/* Static Contact Link */}
                <Link href="/contact">
                  <span className="bg-gray-300 text-primary font-bold px-6 py-2 sm:px-8 sm:py-3 rounded-lg hover:bg-gray-500 transition animate-button">
                    Contact
                  </span>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default Carousel_Image;
