import React from 'react';
import { FaMapMarkerAlt, FaEnvelope, FaPhoneAlt } from 'react-icons/fa';

export default function Contact_Info_Page_style() {
    return (
        <div className="p-6 shadow-md rounded-md me-5 mb-5">
            <div className="mb-6">
                <h1 className="text-3xl font-bold text-[#0e2f4d]">Contact Information</h1>
            </div>

            {/* Address Section */}
            <div className="card mb-4 p-4 border border-gray-300 rounded-md shadow-sm">
                <div className="flex items-center space-x-3 mb-2">
                    <FaMapMarkerAlt className="text-primary text-xl" />
                    <span className="font-semibold text-lg">Address</span>
                </div>
                <p className="text-gray-700">
                    P.BOX12140 Building NO 90, Street 185 Al-Azizia 55  <br />
                    Doha Qatar
                </p>
            </div>

            {/* Email Section */}
            <div className="card mb-4 p-4 border border-gray-300 rounded-md shadow-sm">
                <div className="flex items-center space-x-3 mb-2">
                    <FaEnvelope className="text-primary text-xl" />
                    <span className="font-semibold text-lg">Email</span>
                </div>
                <p className="text-gray-700">info@niebogran.com</p>
            </div>

            {/* Phone Numbers Section */}
            <div className="card mb-4 p-4 border border-gray-300 rounded-md shadow-sm">
                <div className="flex items-center space-x-3 mb-2">
                    <FaPhoneAlt className="text-primary text-xl" />
                    <span className="font-semibold text-lg">Call Us</span>
                </div>
                <p className="text-gray-700">
                    +974 7789 5861
                </p>
            </div>
        </div>
    );
}
