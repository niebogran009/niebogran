import React from 'react';

export default function Map() {
    return (
        <div className="p-4">
            <div className="w-full h-[500px]">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d28870.483002686327!2d51.447394949999996!3d25.24331105!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e45da0c057e2873%3A0x973a4cf93903a086!2sAl%20Aziziyah%2C%20Doha%2C%20Qatar!5e0!3m2!1sen!2s!4v1735122263323!5m2!1sen!2s"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
            </div>
        </div>
    );
}
