import { useState } from 'react';
import { FaUser, FaPhone, FaEnvelope, FaPaperPlane } from 'react-icons/fa';

export default function Home() {
  const [formData, setFormData] = useState({ name: '', phone: '', email: '', message: '' });
  const [responseMessage, setResponseMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    const res = await fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    const data = await res.json();
    if (data.error) {
      setResponseMessage(`❌ ${data.error}`);
    } else {
      setResponseMessage(`✅ ${data.success}`);
      setFormData({ name: '', phone: '', email: '', message: '' });
    }
  };

  return (
    <div className="flex items-center justify-center  shadow-lg py-10 w-[450px]">
      <div className="w-full max-w-md sm:max-w-2xl lg:max-w-xl rounded-lg p-8 ">
        <h1 className="text-3xl font-semibold text-center text-red-500 mb-6">Contact Us</h1>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex items-center border border-gray-300 rounded-lg px-4 py-2">
            <FaUser className="text-gray-500 mr-2" />
            <input
              type="text"
              placeholder="Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              className="w-full focus:ring-2 focus:ring-red-500 focus:outline-none text-lg"
            />
          </div>

          <div className="flex items-center border border-gray-300 rounded-lg px-4 py-2">
            <FaPhone className="text-gray-500 mr-2" />
            <input
              type="text"
              placeholder="Phone"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              required
              className="w-full focus:ring-2 focus:ring-red-500 focus:outline-none text-lg"
            />
          </div>

          <div className="flex items-center border border-gray-300 rounded-lg px-4 py-2">
            <FaEnvelope className="text-gray-500 mr-2" />
            <input
              type="email"
              placeholder="Email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
              className="w-full focus:ring-2 focus:ring-red-500 focus:outline-none text-lg"
            />
          </div>

          <div className="flex items-start border border-gray-300 rounded-lg px-4 py-2">
            <FaPaperPlane className="text-gray-500 mr-2" />
            <textarea
              placeholder="Message"
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              required
              className="w-full h-40 focus:ring-2 focus:ring-red-500 focus:outline-none text-lg"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-red-900 text-white py-2 px-4 rounded-lg hover:bg-primary font-bold transition duration-300"
          >
            Submit
          </button>
        </form>

        {responseMessage && (
          <p
            className={`mt-6 text-center font-semibold ${responseMessage.startsWith('❌') ? 'text-red-500' : 'text-green-500'}`}
          >
            {responseMessage}
          </p>
        )}
      </div>
    </div>
  );
};
