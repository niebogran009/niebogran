import React from 'react';

// Correct imports for icons
import { FaCar, FaCarSide } from 'react-icons/fa'; // FontAwesome icons
import { GiRoad } from 'react-icons/gi'; // Game Icons
import Services_Page_Tabs from '../Services/Pages/Services_Page_Tabs/Services_Page_Tabs';
import ALL_Submenu_contact from '../Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact';
import PROJECTS_MANAGEMENT_para from '../Services/Pages/ELECTRICAL_SYSTEMS/PROJECTS_MANAGEMENT_para/PROJECTS_MANAGEMENT_para';
import Card_Reuse from '../Services/Pages/ELECTRICAL_SYSTEMS/Card_Reuse/Card_Reuse';

export default function ROADS_WORK_STYLE() {
  return (
    <div >

      <div className='flex'>

      <div className='hidden md:block'>
      <Services_Page_Tabs />
      <ALL_Submenu_contact />
      </div>

      <div>
      <PROJECTS_MANAGEMENT_para
        title=""
        content="Niebogran Trading & Contracting is renowned for its exceptional quality in road works, supported by advanced equipment and a team of highly trained operators. Our workforce has extensive experience in executing a wide range of road projects, including dirt roads, paved roads, and runways, as well as designing and completing complex large-scale projects in the field.  "
        content2="We employ modern technologies, a fleet of transport equipment, and cutting-edge tools to ensure superior results. Niebogran is distinguished by a highly efficient team skilled in the design and implementation of all road works, including asphalt paving and utilizing the latest methods and equipment."
        imageUrl="/Roads_Works.png"
        imageAlt="ROADS WORK Image"
      />

      <div className="grid sm:grid-cols-1 md:grid-cols-3 gap-4 p-4">
        <Card_Reuse id="01" title="Heating, Ventilation, and HVAC" icon={<GiRoad size={28} />} />
        <Card_Reuse id="02" title="Plumbing and Piping" icon={<FaCar size={28} />} />
        <Card_Reuse id="03" title="Drainage and Sewage" icon={<FaCarSide size={28} />} />
      </div>
      </div>
      </div>

    </div>
  );
}
