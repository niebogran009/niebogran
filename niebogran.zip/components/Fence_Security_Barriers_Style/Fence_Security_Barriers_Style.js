import React from 'react'
import Image from 'next/image';
import Link_Pages_Projects from '../Link_Pages_Projects/Link_Pages_Projects';
import ALL_Submenu_contact from '../Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact';
import Project_name_card_red from '../PROJECTS/Project_name_card_red/Project_name_card_red';
export default function Fence_Security_Barriers_Style() {
  const cardData = [
    // Red Cards
    {
      bgColor: "bg-[#c52129]",
      title: "Project Name",
      description: "Implementing a rear Barrier in an Infrastructure Project.",
      amount: "####",
    },
    {
      bgColor: "bg-[#c52129]",
      title: "Project Name",
      description: "Infrastructure Project for the Southern Area.",
      amount: "####",
    },
    {
      bgColor: "bg-[#c52129]",
      title: "Project Name",
      description: "Implementing a Security Fence",
      amount: "#####",
    },
    // Primary Cards
    {
      bgColor: "bg-primary",
      title: "Project Name",
      description: "Supplying & Installing a Fence for a Train Project.",
      amount: "#####",
    },
    {
      bgColor: "bg-primary",
      title: "Project Name",
      description: "A Project to Construct a Fence and a Project to Repair a Fence.",
      amount: "####",
    },
    {
      bgColor: "bg-primary",
      title: "Project Name",
      description: "Fencing Works for Enclosing the Southern Area.",
      amount: "####",
    },
  ];

  return (
    <div>
      <div className='flex'>

        <div className='hidden md:block'>
          <Link_Pages_Projects />
          <ALL_Submenu_contact />
        </div>

        <div className="px-4 sm:px-6 lg:px-8">

{/* Main Image */}
<div className="mt-10">
  <Image
    src="/Fence_Security_Barriers.png"
    width={950}
    height={100}
    className="w-full h-auto"
    alt="Main Image"
  />
</div>

{/* Flex Container */}
<div className="flex flex-col lg:flex-row mt-8 gap-6">

  {/* Left Image */}
  <div className="flex-shrink-0">
    <Image
      src="/Profile-1-80-rotated.webp"
      width={400}
      height={0}
      className="w-full max-w-[400px] h-auto mx-auto lg:mx-0"
      alt="Left Image"
    />
  </div>

  {/* Right Images */}
  <div className="flex-1">
    <Image
      src="/Profile-1-81.webp"
      width={500}
      height={0}
      className="w-full h-auto"
      alt="Top Right Image"
    />

    <Image
      src="/Profile-1-83.webp"
      width={500}
      height={500}
      className="w-full h-[50vh] mt-10 object-cover"
      alt="Bottom Right Image"
    />
  </div>

</div>


{/* Project Name Card */}
<div className="mt-10">
  <Project_name_card_red data={cardData} />
</div>

</div>




      </div>
    </div>
  )
}
