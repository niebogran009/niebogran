import React from "react";
import { FaBusinessTime, FaHardHat, FaBrush, FaTools, FaGlobe, FaCogs, FaIndustry, FaSatellite } from 'react-icons/fa';
import Services_Page_Tabs from "../Services/Pages/Services_Page_Tabs/Services_Page_Tabs";
import ALL_Submenu_contact from "../Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact";
import PROJECTS_MANAGEMENT_para from "../Services/Pages/ELECTRICAL_SYSTEMS/PROJECTS_MANAGEMENT_para/PROJECTS_MANAGEMENT_para";
import Card_Reuse from "../Services/Pages/ELECTRICAL_SYSTEMS/Card_Reuse/Card_Reuse";


export default function ServicesMenu_STYLE() {





  return (
    <>
<div className="flex">
    
<div className=" ">
  {/* Always visible on md+ screen sizes */}
  <div className="md:block hidden">
    <Services_Page_Tabs />
  </div>

  {/* Visible only on md+ screen sizes */}
  <div className="md:block hidden">
    <ALL_Submenu_contact />
  </div>
</div>
 


<div className="">
    <PROJECTS_MANAGEMENT_para
title="Niebogran Trading  & Contracting"
content="is driven by a highly qualified and professional management team. With our head office located in Doha, Qatar, our focus is on collaborating closely with clients to deliver tailored project management solutions.."
content2="We are committed to understanding customer requirements, fostering creative thinking, solving problems efficiently, and delivering outcomes that exceed expectations. At Niebogran, we prioritize our clients' interests and are passionate about implementing their project needs to achieve the best possible results."

imageUrl="/PROJECTS_MANAGEMENT.webp"
imageAlt="Niebogran  Company Profile"


/>

<div className="grid grid-cols-2 sm:grid-cols-1 md:grid-cols-4 gap-4 p-4">
  <Card_Reuse id="01" title="Projects Management" icon={<FaBusinessTime size={28} />} />
  <Card_Reuse id="02" title="Construction Management" icon={<FaHardHat size={28} />} />
  <Card_Reuse id="03" title="Design Department" icon={<FaBrush size={28} />} />
  <Card_Reuse id="04" title="Technical Engineering" icon={<FaTools size={28} />} />
  <Card_Reuse id="05" title="Electronic Space" icon={<FaGlobe size={28} />} />
  <Card_Reuse id="06" title="Engineering Loads for Works" icon={<FaCogs size={28} />} />
  <Card_Reuse id="07" title="MEP Engineering Department" icon={<FaIndustry size={28} />} />
  <Card_Reuse id="08" title="Communications Systems Department" icon={<FaSatellite size={28} />} />
</div>
    </div>
    </div>


   

    
    </>
  );
}
