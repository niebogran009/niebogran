import React, { useState, useEffect } from 'react';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';
import Slider from 'react-slick'; // Import react-slick
import { FaChevronLeft, FaChevronRight } from 'react-icons/fa'; // Importing carousel arrows
import { FaWrench, FaLightbulb, FaCogs, FaRoad, FaShieldAlt, FaDotCircle } from 'react-icons/fa'; // Icons
import Link from 'next/link';

// Include necessary slick-carousel styles
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

export default function Niebogran_Service() {
  const [products, setProducts] = useState([]);

  // Fetch mock product data
  useEffect(() => {
    const mockProducts = [
      { id: 1, name: 'Project Management', icon: <FaWrench />, inventoryStatus: 'Niebogran  Trading & Contracting Company is a highly qualified and professional', url: '/page/Services/Pages/PROJECTS_MANAGEMENT' },
      { id: 2, name: 'Electrical Systems', icon: <FaLightbulb />, inventoryStatus: 'Our Engineers are specialized, Trained and experienced installation and maintenance', url: '/page/Services/Pages/ELECTRICAL_SYSTEMS' },
      { id: 3, name: 'Mechanical System', icon: <FaCogs />, inventoryStatus: 'Niebogran  Trading & Contracting Company is a highly qualified and professional', url: '/page/Services/Pages/MECHANICAL_SYSTEMS' },
      { id: 4, name: 'Roads Works', icon: <FaRoad />, inventoryStatus: 'Niebogran  Company is known for its quality works in the field road works, as a result of', url: '/page/Services/Pages/ROADS_WORK' },
      { id: 5, name: 'Metal Barriers', icon: <FaShieldAlt />, inventoryStatus: 'Execution of Metal barriers through studying the requirements of the market and projects', url: '/page/Services/Pages/METAL_BARRIERS' },
    ];

    setProducts(mockProducts);
  }, []);

  // Get the severity of product inventory
  const getSeverity = (product) => {
    switch (product.inventoryStatus) {
      case 'this is a para':
        return 'success';
      case 'OUTOFSTOCK':
        return 'danger';
      default:
        return null;
    }
  };

  // Template to render each product
  const productTemplate = (product) => {
    return (
      <div id="services" className="border rounded-lg text-primary shadow-lg p-4  bg-white text-center h-[300px] flex flex-col justify-between">
        {/* Icon Section */}
        <div className="flex justify-center">
          <div
            className="mb-2 flex justify-center text-center items-center w-16 bg-red-900 rounded-full hover:bg-primary p-4"
            style={{ fontSize: '2rem', color: 'white' }}
          >
            {product.icon} {/* React Icon */}
          </div>
        </div>

        {/* Name Section */}
        <p className="text-xl font-semibold mb-2">{product.name}</p>

        {/* Status Section */}
        <Tag value={product.inventoryStatus} severity={getSeverity(product)}></Tag>

        {/* Buttons Section */}
        <div className="flex justify-center gap-3 mt-2">
          <Button icon="pi pi-search" className="p-button-rounded" />
          <Button icon="pi pi-star-fill" className="p-button-success p-button-rounded" />
        </div>

        {/* More Details Section */}
        <div className="mt-2">
          <Link
            href={product.url}
            className="p-button bg-primary p-1 px-3 hover:bg-red-900 text-white rounded-lg p-button-warning p-button-rounded inline-block font-bold text-[13px]"
          >
            <span>More Details</span>
          </Link>
        </div>
      </div>
    );
  };

  // Carousel settings
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 4,
    autoplay: true, // Enable autoplay
    autoplaySpeed: 2000, // Slide every 2 seconds
    nextArrow: <FaChevronRight className="text-2xl text-gray-700 cursor-pointer absolute top-1/2 right-4 transform -translate-y-1/2 z-10" />,
    prevArrow: <FaChevronLeft className="text-2xl text-gray-700 cursor-pointer absolute top-1/2 left-4 transform -translate-y-1/2 z-10" />,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <>
      <div className="my-5 mt-10">
        <h1 className="text-center text-primary text-lg font-bold">Niebogran  Services</h1>
        <div className="flex justify-center">
          <div className="text-red-700 flex text-xl">
            <span className="text-primary">__________</span>
            <FaDotCircle className="mt-3" />
            <span className="text-primary">__________</span>
          </div>
        </div>
      </div>

      <div className="py-6 relative ">
        <div className="sm:w-full md:w-[90%] lg:w-[85%] mx-auto px-6"> {/* Increased width */}
          <Slider {...settings}>
            {products.map((product) => (
              <div key={product.id} className="px-4 ">
                {productTemplate(product)}
              </div>
            ))}
          </Slider>
        </div>
      </div>
    </>
  );
}
