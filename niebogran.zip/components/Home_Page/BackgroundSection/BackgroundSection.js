import React from 'react';
import Link from 'next/link';

const BackgroundSection = () => {
  return (
    <div
      className=" relative h-[70vh] bg-cover bg-no-repeat bg-scroll"
      style={{
        backgroundImage: 'url("/con002-scaled.webp")',
        backgroundPosition: 'center', // Center the image to make sure it's always in the center of the section
        backgroundSize: 'cover', // Ensure the image covers the section fully without distortion
      }}
    >
      {/* primary overlay with reduced opacity to enhance text visibility */}
      <div className="absolute inset-0 bg-black bg-opacity-70" />

      <div className="flex items-center justify-start pl-10 h-full relative z-10">
        <div className="text-white space-y-6">
          {/* Heading Section */}
          <div id="ultimate-heading-7047675bf78166479" className="text-left">
            <h1 className="font-bold text-white text-4xl md:text-5xl mb-5">
              Have a Large Project?
            </h1>
            {/* Subheading */}
            <div className="font-normal text-lg md:text-xl my-10">
              If you have a project, kindly contact us by sending an email to{' '}
              <Link href="info@niebogran.com" className="text-white underline">
                <span >
                info@niebogran.com
                </span>{' '}
              </Link>
              or sending a  <br /> message through the button below, and we will contact you as soon as possible.
            </div>
          </div>
          {/* Button */}
          <div className="btn-align-left ">
            <Link href='/contactPage'>
              <span

                className=" default-btn-shortcode dt-btn dt-btn-m link-hover-off bg-primary text-white py-4 px-6 rounded-lg font-bold hover:bg-red-900 transition"
                title="Contact">
                Send a Message
              </span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BackgroundSection;
