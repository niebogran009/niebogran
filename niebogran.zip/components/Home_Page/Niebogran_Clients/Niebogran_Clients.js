import React, { useState, useEffect } from 'react';
import Slider from 'react-slick';
import { FaChevronLeft, FaChevronRight } from 'react-icons/fa';
import Image from 'next/image';

export default function Niebogran_Clients() {
  const [products, setProducts] = useState([]);
  const [selectedImage, setSelectedImage] = useState(null); // State for the selected image

  useEffect(() => {
    const mockProducts = [
      { id: 1, image: '/clients/clients01.webp' },
      { id: 2, image: '/clients/clients02.webp' },
      { id: 4, image: '/clients/clients04.webp' },
      { id: 5, image: '/clients/clients05.webp' },
      { id: 6, image: '/clients/clients06.webp' },
      { id: 9, image: '/clients/clients09.webp' },
      { id: 10, image: '/clients/clients10.webp' },
      { id: 11, image: '/clients/clients11.webp' },
      { id: 12, image: '/clients/clients12.webp' },
      { id: 14, image: '/clients/clients14.webp' },
      { id: 15, image: '/clients/clients15.webp' },
    ];

    setProducts(mockProducts);
  }, []);

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 7,
    slidesToScroll: 6,
    autoplay: true, // Enable auto-play
    autoplaySpeed: 2000, // Set interval to 2 seconds
    nextArrow: <FaChevronRight color='white' className="text-2xl text-white cursor-pointer absolute top-1/2 right-4 transform -translate-y-1/2 z-10" />,
    prevArrow: <FaChevronLeft color='white' className="text-2xl text-white cursor-pointer absolute top-1/2 left-4 transform -translate-y-1/2 z-10" />,
    responsive: [
      {
        breakpoint: 1024,
        settings: { slidesToShow: 3, slidesToScroll: 3 },
      },
      {
        breakpoint: 768,
        settings: { slidesToShow: 3, slidesToScroll: 3 },
      },
      {
        breakpoint: 480,
        settings: { slidesToShow: 2, slidesToScroll: 2 },
      },
    ],
  };

  return (
    <div
      className=" py-6 relative flex justify-center items-center "
      style={{
        backgroundImage: "url('/engineer.jpg')",
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundColor: 'primary',  // Set background color to primary
        height: '60vh',  // Set the height of the background image to 70vh
      }}
    >
      <Slider {...settings} className="w-[85%]">
        {products.map((product) => (
          <div key={product.id} className="px-2 sm:px-4">
            <div className="flex justify-center items-center transition-transform ease-in-out duration-200 hover:scale-105">
              <Image
                src={product.image}
                alt={`Product ${product.id}`}
                width={100}
                height={100}
                className="w-40 h-40 object-cover rounded-lg mb-4  cursor-pointer"
                onClick={() => setSelectedImage(product.image)} // Set the selected image
              />
            </div>
          </div>
        ))}
      </Slider>

      {/* Modal */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex justify-center items-center z-50">
          <div className="relative">
            <Image
              src={selectedImage}
              alt="Selected"
              width={500}
              height={500}
              className="w-auto h-auto max-w-screen-md max-h-screen-md rounded-lg"
            />
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-2 right-2 text-white bg-red-500 hover:bg-red-700 rounded-full p-2"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
