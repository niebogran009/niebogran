import Link from 'next/link'
import React from 'react'

export default function Footer() {
  return (
    <div className='bg-primary py-5  md:mb-0 mb-16'>
      <div className='flex justify-center text-white'>
        Copyright 2023 © Niebogran All Rights Reserved
       
      </div>

    </div>
  )
}
