import React, { useState, useEffect } from 'react';
import { Button } from 'primereact/button';
import { FaChevronLeft, FaChevronRight, FaDotCircle } from 'react-icons/fa';
import Image from 'next/image';
import Link from 'next/link';
import Slider from 'react-slick';

export default function Niebogran_Projects() {
  const [products, setProducts] = useState([]);
  const [heading, setHeading] = useState(''); // Add state for the heading

  // Fetch mock product data
  useEffect(() => {
    const mockProducts = [
      { 
        id: 1, 
        name: 'Fence & Security Barriers', 
        image: '/Fence_Security_Barriers.png',
        link: '/page/Projects/Pages/Fence_Security_Barriers_Style'
      },
      { 
        id: 2, 
        name: 'Electrical Works', 
        image: '/Electrical_Works.png',
        link: '/page/Projects/Pages/Electrical_Works'
      },
      { 
        id: 5, 
        name: 'Constructions', 
        image: '/Constructions.png',
        link: '/page/Projects/Pages/Constructions'
      },
      { 
        id: 6, 
        name: 'Fiber Optic', 
        image: '/Fiber_Optic.png',
        link: '/page/Projects/Pages/Fiber_Optic'
      },
    ];

    setProducts(mockProducts);

    // Set the heading after the component mounts (to prevent hydration issues)
    setHeading('Niebogran  Projects');
  }, []);

  // Template to render each product
  const productTemplate = (product) => {
    return (
      <div id='projects' className="border rounded-lg shadow-lg bg-white w-[250px] items-center text-center">
        <Image
          src={product.image}
          alt={product.name}
          width={300} // Adjust the width
          height={200} // Adjust the height
          className="w-full h-64 object-cover rounded-lg mb-4"
        />
        <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
        <Link href={product.link}>
          <span className="bg-primary text-sm p-2 px-3 hover:bg-red-900 text-white rounded-lg mb-3 font-bold">
            More Details
          </span>
        </Link>
        <div className="flex justify-center gap-3">
          <Button icon="pi pi-search" className="p-button-rounded" />
          <Button icon="pi pi-star-fill" className="p-button-success p-button-rounded" />
        </div>
      </div>
    );
  };

  // Carousel settings with auto-play enabled
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 4,
    autoplay: true, // Enable auto-play
    autoplaySpeed: 2000, // Set interval to 2 seconds
    nextArrow: <FaChevronRight className="text-2xl text-gray-700 cursor-pointer absolute top-1/2 right-4 transform -translate-y-1/2 z-10" />,
    prevArrow: <FaChevronLeft className="text-2xl text-gray-700 cursor-pointer absolute top-1/2 left-4 transform -translate-y-1/2 z-10" />,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <div className="mb-5 ">
      {/* Render heading only after it is set on the client side */}
      {heading && <h1 className="text-center text-primary text-lg font-bold">{heading}</h1>}
      <div className="flex justify-center">
        <div className="text-red-700 flex text-xl">
          <span className="text-primary">__________</span>
          <FaDotCircle className="mt-3" />
          <span className="text-primary">__________</span>
        </div>
      </div>
      <div className="py-6 relative">
        <div className="sm:w-full md:w-[90%] lg:w-[85%] mx-auto px-6">
          <Slider {...settings}>
            {products.map((product) => (
              <div key={product.id} className="px-4 flex justify-center">
                {productTemplate(product)}
              </div>
            ))}
          </Slider>
        </div>
      </div>
    </div>
  );
}
