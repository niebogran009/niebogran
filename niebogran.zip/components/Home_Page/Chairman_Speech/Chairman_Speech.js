import React, { useEffect, useState } from 'react';
import Image from 'next/image';

const Chairman_Speech = () => {
    const [isInView, setIsInView] = useState(false);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsInView(true); // Set animation to true when element comes into view
                }
            },
            {
                threshold: 0.5, // Trigger when 50% of the element is visible
            }
        );

        const element = document.getElementById('chairman-speech');
        if (element) {
            observer.observe(element);
        }

        return () => {
            if (element) {
                observer.unobserve(element);
            }
        };
    }, []);

    return (
        <div id="chairman-speech" className="flex flex-wrap justify-around sm:px-10  my-10">
            {/* Left Column */}
            <div className="w-full sm:w-1/2 bg-gray-100 p-5">
                <div className="text-left">
                    <h2 className="text-primary font-bold text-2xl mb-2">Chairman Speech</h2>
                    <div className="flex items-center gap-2 mb-4">
                        <div className="text-red-600 text-lg">
                            <i className="fas fa-circle"></i>
                        </div>
                        <div className="flex-grow h-px bg-gray-700"></div>
                    </div>
                    {/* 1 */}
                    <p
                        className={`text-primary mb-4 ${isInView ? 'animate-slide-up' : ''}`}
                    >
                        Our ultimate goal is to empower our clients to achieve and surpass their objectives. At <span className='font-bold'>Niebogran</span> Trading & Contracting, we combine expertise, resources, and innovative strategies to deliver outstanding outcomes in every project. Communication and flexibility lie at the core of our operations, enabling us to adapt seamlessly to challenges and meet the market ever-changing demands..
                    </p>
                    {/* 2 */}
                    <p
                        className={`text-primary mb-4 ${isInView ? 'animate-slide-up-delay' : ''}`}
                    >
                        With extensive experience in managing diverse and complex projects, we integrate cutting-edge technologies and evolve alongside our clients needs. This approach not only enhances our capacity to deliver exceptional results but also strengthens our reputation as a trusted name in the industry.
                    </p>
                    {/* 3 */}
                    <p
                        className={`text-primary mb-4 ${isInView ? 'animate-slide-up-delay' : ''}`}
                    >
                       We are dedicated to pioneering new technologies while fostering a culture of critical thinking and problem-solving among our teams. At Niebogran, we see success as a journey, not a destination. We believe sustained success comes from setting clear, achievable goals and employing effective management strategies to consistently deliver excellence.

                    </p>
                    {/* 4 */}
                    <p
                        className={`text-primary mb4 ${isInView ? 'animate-slide-up-delay' : ''}`}
                    >
                   Our vision is to grow, innovate, and lead as one of the top companies in our field. By delivering superior products and services that exceed expectations, we aim to create lasting value for our clients and remain a benchmark of quality and reliability.
                    </p>
                </div>
            </div>

            {/* Right Column */}
            <div className="w-full sm:w-1/2 flex justify-center items-center bg-gray-100 p-5 px-10">
                <figure>
                    <Image
                        src="/about_img.jpg"
                        alt="Al-Dafe Company Profile"
                        className="w-[600px] h-[490px] border border-gray-300"
                        width={384}
                        height={384}
                    />
                </figure>
            </div>
        </div>
    );
};

export default Chairman_Speech;
