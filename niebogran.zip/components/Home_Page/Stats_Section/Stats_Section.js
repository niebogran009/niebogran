import React, { useEffect, useState } from "react";
import { GoProjectSymlink } from "react-icons/go";
import { GrGroup } from "react-icons/gr";
import { LiaToolsSolid } from "react-icons/lia";
import { AiOutlineSafetyCertificate } from "react-icons/ai";

const Stats_Section = () => {
  const [count, setCount] = useState({
    admin: 0,
    tech: 0,
    equipment: 0,
    vehicles: 0,
  });
  const [isInView, setIsInView] = useState(false);

  const statsData = [
    {
      key: "admin",
      icon: <GoProjectSymlink className="text-red-900" />,
      title: "Completed Projects",
      target: 450,
    },
    {
      key: "tech",
      icon: <GrGroup className="text-red-900" />,
      title: "Client Satisfaction",
      target: 98,
    },
    {
      key: "equipment",
      icon: <LiaToolsSolid className="text-red-900" />,
      title: "Operational Reach",
      target: 100,
    },
    {
      key: "vehicles",
      icon: <AiOutlineSafetyCertificate  className="text-red-900" />,
      title: "Safety Records",
      target: 100,
    },
  ];

  const incrementCount = (target, key) => {
    let count = 0;
    const interval = setInterval(() => {
      count += Math.ceil(target / 100); // Increment by a small number
      if (count >= target) {
        clearInterval(interval);
        setCount((prev) => ({ ...prev, [key]: target }));
      } else {
        setCount((prev) => ({ ...prev, [key]: count }));
      }
    }, 20);
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true); // Set animation to true when section is in view
          statsData.forEach((stat) => {
            incrementCount(stat.target, stat.key);
          });
        } else {
          setIsInView(false); // Reset animation state if section is not in view
        }
      },
      {
        threshold: 0.5, // Trigger when 50% of the section is visible
      }
    );

    const element = document.getElementById("stats-section");
    if (element) {
      observer.observe(element);
    }

    return () => {
      if (element) {
        observer.unobserve(element);
      }
    };
  }, []);

  return (
    <div id="stats-section" className="bg-[#0e2f4d] py-10 my-10">
      <div className="flex flex-wrap gap-6 justify-center">
        {statsData.map((stat) => (
          <div
            key={stat.key}
            className="w-full sm:w-1/2 md:w-1/4 lg:w-1/5 bg-white rounded-lg shadow-md"
          >
            <div
              className={`text-center p-6 ${
                isInView ? "animate-slide-up" : ""
              }`}
            >
              <div className="text-red-900 text-4xl mb-3 flex justify-center">
                {stat.icon}
              </div>
              <div className="text-5xl text-primary">{count[stat.key]}</div>
              <div className="text-lg text-primary">{stat.title}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Stats_Section;
