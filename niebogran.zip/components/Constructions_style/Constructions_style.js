import React from 'react'
import Link_Pages_Projects from '../Link_Pages_Projects/Link_Pages_Projects';
import ALL_Submenu_contact from '../Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact';
import Constructions_style_image from '../PROJECTS/Constructions_style_image/Constructions_style_image';
import Images_Two from '../PROJECTS/Images_Two/Images_Two';
import Project_name_card_red from '../PROJECTS/Project_name_card_red/Project_name_card_red';

export default function Constructions_style() {
    const cardData = [
        // Red Cards
        {
          bgColor: "bg-[#c52129]",
          title: "Project Name",
          description: "Implementing Buildings in the Regions of Al Ruwais",
          amount: "#####",
        },
        {
          bgColor: "bg-[#c52129]",
          title: "Project Name",
          description: "Surveillance Centers Constructing  Of Buildings ",
          amount: "#####",
        },
        {
          bgColor: "bg-[#c52129]",
          title: "Project Name",
          description: "Constructing Shades for Schools, Sarks, & Playgrounds",
          amount: "#####",
        },
        // Primary Cards
        {
          bgColor: "bg-primary",
          title: "Project Name",
          description: "Upgrading Telecom Infrastructure",
          amount: "#####",
        },
        {
          bgColor: "bg-primary",
          title: "Project Name",
          description: "Expanding Renewable Energy Facilities",
          amount: "#####",
        },
        {
          bgColor: "bg-primary",
          title: "Project Name",
          description: "Enhancing public health services",
          amount: "#####",
        },
      ];

  return (
    <div>
        <div className='flex'>

        <div className='hidden md:block'>
        <Link_Pages_Projects/>
          <ALL_Submenu_contact />
          </div>
      
      <div>
<Constructions_style_image
    largeSrc="/Constructions.png"
    largeAlt="Large construction image"
/>


<div>
<Images_Two
 smallSrc1="/construction-03.webp"
 smallAlt1="Smaller construction image 1"
 smallSrc2="/construction-02.webp"
 smallAlt2="Smaller construction image 2"
/>
</div>

<div className="">
      <Project_name_card_red data={cardData} />
    </div>

      </div>



          </div>
    </div>
  )
}
