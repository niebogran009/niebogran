import React from 'react';
import { FaHome, FaInfoCircle, FaUsers, FaPhoneAlt } from 'react-icons/fa';
import Link from 'next/link';
import { useRouter } from 'next/router';

export default function Mobile_Menu() {
  const router = useRouter();

  // Function to apply active class for icons
  const getIconActiveClass = (path) => {
    return router.pathname === path ? 'text-red-900' : 'text-white';
  };

  return (
    <div className="fixed bottom-0 left-0 w-full bg-primary text-white z-50">
      <div className="flex justify-around py-2 font-bold">
        <Link href="/" passHref>
          <div className="flex flex-col items-center cursor-pointer">
            <FaHome className={`text-xl mb-1 ${getIconActiveClass('/')}`} />
            <span className="text-sm text-white">Home</span>
          </div>
        </Link>
        <Link href="/about" passHref>
          <div className="flex flex-col items-center cursor-pointer">
            <FaInfoCircle className={`text-xl mb-1 ${getIconActiveClass('/about')}`} />
            <span className="text-sm text-white">About</span>
          </div>
        </Link>
        <Link href="/Clients" passHref>
          <div className="flex flex-col items-center cursor-pointer">
            <FaUsers className={`text-xl mb-1 ${getIconActiveClass('/Clients')}`} />
            <span className="text-sm text-white">Clients</span>
          </div>
        </Link>
        <Link href="/contactPage" passHref>
          <div className="flex flex-col items-center cursor-pointer">
            <FaPhoneAlt className={`text-xl mb-1 ${getIconActiveClass('/contactPage')}`} />
            <span className="text-sm text-white">Contact Us</span>
          </div>
        </Link>
      </div>
    </div>
  );
}
