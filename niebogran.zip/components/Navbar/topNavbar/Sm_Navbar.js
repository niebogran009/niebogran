import Image from "next/image";
import Link from "next/link";
import React, { useState, useEffect, useRef } from "react";
import { FaAngleUp, FaAngleDown, FaBars, FaTimes } from "react-icons/fa";

const Sm_Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const menuRef = useRef(null);
  const dropdownRef = useRef(null);

  // Toggle the dropdown on click
  const toggleDropdown = (dropdownName) => {
    // If the same dropdown is clicked, close it, otherwise open the new one
    setActiveDropdown((prev) => (prev === dropdownName ? null : dropdownName));
  };

  // Close menu or dropdown if clicked outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(event.target) &&
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target)
      ) {
        setIsOpen(false); // Close the menu
        setActiveDropdown(null); // Close the dropdown
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="sm:block md:hidden">
      {/* Top Bar */}
      <div className="flex justify-between items-center px-4 py-3 text-white">
        {/* Logo */}
        <div className="h-[20px] flex justify-center items-center">
          <Image
            src="/Logo.png" // Correct path to your logo image in public folder
            alt="Logo"
            width={300}
            height={90}
            className="h-[90px] w-[300px]"
          />
        </div>

        {/* Button to toggle mobile menu */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="sm:block md:hidden p-2 bg-red-900 text-white font-bold flex items-center gap-2"
        >
          {isOpen ? <FaTimes /> : <FaBars />} {/* Toggle between hamburger and close icon */}
        </button>
      </div>

      {/* Menu items for small screens */}
      <div
        ref={menuRef}
        className={`${
          isOpen ? "block" : "hidden"
        } bg-red-900 text-white px-4 py-2`}
      >
        <ul className="flex flex-col space-y-4">
          {/* Services Dropdown */}
          <li className="relative">
            <button
              onClick={() => toggleDropdown("services")}
              className={`flex items-center text-white hover:text-white hover:bg-red-700 px-4 py-2 rounded-md ${activeDropdown === "services" ? "bg-red-700" : ""}`}
              aria-expanded={activeDropdown === "services"}
            >
              <span className="font-bold">SERVICES</span>
              {activeDropdown === "services" ? (
                <FaAngleUp className="ml-2" />
              ) : (
                <FaAngleDown className="ml-2" />
              )}
            </button>
            {/* Dropdown Items */}
            {activeDropdown === "services" && (
              <div
                ref={dropdownRef}
                className="absolute left-0 text-[17px] bg-gray-200 rounded-md font-bold border-4 border-red-900 w-64 z-10 shadow-lg mt-2"
              >
                <Link href="/page/Services/Pages/PROJECTS_MANAGEMENT">
                  <span className="block px-4 py-2 hover:bg-red-700 text-primary hover:text-white">
                    PROJECTS MANAGEMENT
                  </span>
                </Link>
                <Link href="/page/Services/Pages/ELECTRICAL_SYSTEMS">
                  <span className="block px-4 py-2 hover:bg-red-700 text-primary hover:text-white">
                    ELECTRICAL SYSTEMS
                  </span>
                </Link>
                <Link href="/Page/services/MECHANICAL_SYSTEMS">
                  <span className="block px-4 py-2 hover:bg-red-700 text-primary hover:text-white">
                    MECHANICAL SYSTEMS
                  </span>
                </Link>
                <Link href="/page/Services/Pages/ROADS_WORK">
                  <span className="block px-4 py-2 hover:bg-red-700 text-primary hover:text-white">
                    ROADS WORK
                  </span>
                </Link>
                <Link href="/page/Services/Pages/METAL_BARRIERS">
                  <span className="block px-4 py-2 hover:bg-red-700 text-primary hover:text-white">
                    METAL BARRIERS
                  </span>
                </Link>
              </div>
            )}
          </li>

          {/* Projects Dropdown */}
          <li className="relative">
            <button
              onClick={() => toggleDropdown("projects")}
              className={`flex items-center text-white hover:text-white hover:bg-red-700 px-4 py-2 rounded-md ${activeDropdown === "projects" ? "bg-red-700" : ""}`}
              aria-expanded={activeDropdown === "projects"}
            >
              <span className="font-bold">PROJECTS</span>
              {activeDropdown === "projects" ? (
                <FaAngleUp className="ml-2" />
              ) : (
                <FaAngleDown className="ml-2" />
              )}
            </button>
            {/* Dropdown Items */}
            {activeDropdown === "projects" && (
              <div
                ref={dropdownRef}
                className="absolute left-0 text-[17px] bg-gray-100 rounded-md border-4 border-red-900 w-64 z-10 shadow-lg mt-2"
              >
                <Link href="/page/Projects/Pages/Constructions">
                  <span className="block px-4 py-2 hover:bg-red-700 text-primary hover:text-white">
                    CONSTRUCTIONS
                  </span>
                </Link>
                <Link href="/page/Projects/Pages/Fiber_Optic">
                  <span className="block px-4 py-2 hover:bg-red-700 text-primary hover:text-white">
                    FIBER OPTIC
                  </span>
                </Link>
                <Link href="/page/Projects/Pages/Fence_Security_Barriers_Style">
                  <span className="block px-4 py-2 hover:bg-red-700 text-primary hover:text-white">
                    FENCE & SECURITY BARRIERS
                  </span>
                </Link>
                <Link href="/page/Projects/Pages/Electrical_Works">
                  <span className="block px-4 py-2 hover:bg-red-700 text-primary hover:text-white">
                    ELECTRICAL WORKS
                  </span>
                </Link>
              </div>
            )}
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sm_Navbar;
