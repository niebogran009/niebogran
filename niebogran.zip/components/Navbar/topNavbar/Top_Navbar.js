import React from 'react';
import { FaPhoneAlt, FaEnvelope } from 'react-icons/fa'; // Import icons

export default function Top_Navbar() {
  return (
    <div>
      <div className="w-full">
        <ul className="bg-primary flex flex-wrap justify-between md:justify-end space-x-6 py-2 px-4 md:px-20 items-center">
          <li className="text-white font-bold text-[14px] md:text-[17px] flex items-center space-x-2">
            <FaPhoneAlt size={20} /> {/* Phone icon */}
            <span>+974 7789 5861</span>
          </li>
          <li className="text-white font-bold text-[14px] md:text-[17px] flex items-center space-x-2">
            <FaEnvelope size={20} /> {/* Email icon */}
            <span>info@niebogran.com</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
