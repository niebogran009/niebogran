import { useState } from "react";
import { useRouter } from "next/router"; // Import useRouter
import Link from "next/link";
import { FaAngleUp, FaAngleDown } from "react-icons/fa";
import Image from "next/image";

const Md_Navbar = () => {
  const [activeDropdown, setActiveDropdown] = useState(null);
  const router = useRouter(); // Get the current route

  const toggleDropdown = (dropdownName) => {
    setActiveDropdown((prev) => (prev === dropdownName ? null : dropdownName));
  };

  const isActive = (path) => {
    // Check if the current path matches exactly
    if (path === "/") {
      return router.pathname === path;
    }
    return router.pathname.startsWith(path);
  };

  return (
    <nav className="shadow-md py-3 hidden md:block bg-gray-100">
      <div className="px-16 flex justify-between items-center h-16">
        {/* Logo */}
        <div className="flex justify-center items-center">
          <Image
            src="/Logo.png"
            alt="Logo"
            width={300}
            height={150}
            className="h-[150px] w-[300px]"
          />
        </div>

        {/* Navigation Links */}
        <div className="flex font-semibold items-center space-x-4">
          <Link
            href="/"
            className={`px-4 py-2 rounded-lg transition ${
              isActive("/") ? "bg-red-900 text-white font-bold" : "text-primary hover:text-white hover:bg-red-900"
            }`}
          >
            HOME
          </Link>
          <Link
            href="/about"
            className={`px-4 py-2 rounded-lg transition ${
              isActive("/about") ? "bg-red-900 text-white font-bold" : "text-primary hover:text-white hover:bg-red-900"
            }`}
          >
            ABOUT <span className="hidden lg:inline">Us</span>
          </Link>

          {/* Services Dropdown */}
          <div
            className="relative group"
            onMouseEnter={() => toggleDropdown("services")}
            onMouseLeave={() => setActiveDropdown(null)}
          >
            <Link
              href="/page/Services/Services"
              className={`flex items-center px-4 py-2 rounded-lg transition ${
                activeDropdown === "services" || isActive("/page/Services")
                  ? "bg-red-900 text-white font-bold"
                  : "text-primary hover:text-white hover:bg-red-900"
              }`}
            >
              SERVICES
              {activeDropdown === "services" ? (
                <FaAngleUp className="ml-2" />
              ) : (
                <FaAngleDown className="ml-2" />
              )}
            </Link>
            {activeDropdown === "services" && (
              <div className="absolute left-0 bg-white shadow-md border rounded-lg w-64 z-20">
                {[
                  { href: "/page/Services/Pages/PROJECTS_MANAGEMENT", label: "PROJECTS MANAGEMENT" },
                  { href: "/page/Services/Pages/ELECTRICAL_SYSTEMS", label: "ELECTRICAL SYSTEMS" },
                  { href: "/page/Services/Pages/MECHANICAL_SYSTEMS", label: "MECHANICAL SYSTEMS" },
                  { href: "/page/Services/Pages/ROADS_WORK", label: "ROADS WORK" },
                  { href: "/page/Services/Pages/METAL_BARRIERS", label: "METAL BARRIERS" },
                ].map((item, index) => (
                  <Link key={index} href={item.href}>
                    <span
                      className={`block px-4 py-2 text-sm transition ${
                        isActive(item.href)
                          ? "bg-red-900 text-white"
                          : "hover:bg-red-900 hover:text-white"
                      }`}
                    >
                      {item.label}
                    </span>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* Projects Dropdown */}
          <div
            className="relative group"
            onMouseEnter={() => toggleDropdown("projects")}
            onMouseLeave={() => setActiveDropdown(null)}
          >
            <Link
              href="/page/Projects/Projects_Page"
              className={`flex items-center px-4 py-2 rounded-lg transition ${
                activeDropdown === "projects" || isActive("/page/Projects")
                  ? "bg-red-900 text-white font-bold"
                  : "text-primary hover:text-white hover:bg-red-900"
              }`}
            >
              PROJECTS
              {activeDropdown === "projects" ? (
                <FaAngleUp className="ml-2" />
              ) : (
                <FaAngleDown className="ml-2" />
              )}
            </Link>
            {activeDropdown === "projects" && (
              <div className="absolute left-0 bg-white shadow-md border rounded-lg w-64 z-20">
                {[
                  { href: "/page/Projects/Pages/Constructions", label: "CONSTRUCTIONS" },
                  { href: "/page/Projects/Pages/Fiber_Optic", label: "FIBER OPTIC" },
                  { href: "/page/Projects/Pages/Fence_Security_Barriers_Style", label: "FENCE & SECURITY BARRIERS" },
                  { href: "/page/Projects/Pages/Electrical_Works", label: "ELECTRICAL WORKS" },
                ].map((item, index) => (
                  <Link key={index} href={item.href}>
                    <span
                      className={`block px-4 py-2 text-sm transition ${
                        isActive(item.href)
                          ? "bg-red-900 text-white"
                          : "hover:bg-red-900 hover:text-white"
                      }`}
                    >
                      {item.label}
                    </span>
                  </Link>
                ))}
              </div>
            )}
          </div>

          <Link
            href="/Clients"
            className={`px-4 py-2 rounded-lg transition ${
              isActive("/Clients") ? "bg-red-900 text-white font-bold" : "text-primary hover:text-white hover:bg-red-900"
            }`}
          >
            CLIENTS
          </Link>
          <Link
            href="/contactPage"
            className={`px-4 py-2 rounded-lg transition ${
              isActive("/contactPage")
                ? "bg-red-900 text-white font-bold"
                : "text-primary hover:text-white hover:bg-red-900"
            }`}
          >
            CONTACT <span className="hidden lg:inline">Us</span>
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Md_Navbar;
