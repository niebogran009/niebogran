module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
    "./styles/**/*.{css,scss}", // Include your styles folder
  ],
  theme: {
    extend: {
      colors: {
        primary: "#0e2f4d", // Add custom color here
        
      },
    },
  },
  plugins: [],
}
