import AboutStyleCom from '@/components/About/AboutStyleCom/AboutStyleCom'
import Contact_Form from '@/components/Contact_page_style/Contact_Form'
import Contact_Info_Page_style from '@/components/Contact_page_style/Contact_Info_Page_style'
import Map from '@/components/Contact_page_style/Map'
import Footer from '@/components/Home_Page/Footer/Footer'
import React from 'react'

export default function contactPage() {
  return (
    <div>

<AboutStyleCom title="CONTACT US" />

      <div className='flex flex-wrap justify-center mt-10 '>
      <Contact_Info_Page_style /> 
            <Contact_Form/>
      </div>
            <Map/>

            <Footer/>
    </div>
  )
}
