// pages/api/contact.js

import nodemailer from 'nodemailer';

export default function handler(req, res) {
  if (req.method === 'POST') {
    const { name, phone, email, message } = req.body;

    // Create transporter for Gmail
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'arsalanjunejo2007@gmail.com', // Your Gmail address
        pass: 'rxrn fhco cohh kzqx', // Your Gmail App password
      },
    });

    // Email content
    const mailOptions = {
      from: email, // Sender's email address
      to: 'sales.niebogran@gmail.com', // Receiver's email address
      subject: 'New Contact Form Submission',
      text: `You have a new contact form submission:

      Name: ${name}
      Phone: ${phone}
      Email: ${email}
      Message: ${message}`,
    };

    // Send email
    transporter.sendMail(mailOptions, (err, info) => {
      if (err) {
        console.error('Error sending email:', err);
        return res.status(500).json({ error: 'Error sending email' });
      }

      // Send success response back to the client
      return res.status(200).json({ success: 'Your message has been sent successfully' });
    });
  } else {
    res.status(405).json({ error: 'Method not allowed' });
  }
}
