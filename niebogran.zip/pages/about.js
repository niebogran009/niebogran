import AboutStyleCom from '@/components/About/AboutStyleCom/AboutStyleCom'
import Message_From_CEO from '@/components/About/AboutStyleCom/Message_From_CEO'
import BUSINESS_AREAS_ANDCLASSIFICATIONS from '@/components/About/BUSINESS_AREAS_ANDCLASSIFICATIONS/BUSINESS_AREAS_ANDCLASSIFICATIONS'
import BackgroundSection from '@/components/Home_Page/BackgroundSection/BackgroundSection'
import Chairman_Speech from '@/components/Home_Page/Chairman_Speech/Chairman_Speech'
import Footer from '@/components/Home_Page/Footer/Footer'
import Stats_Section from '@/components/Home_Page/Stats_Section/Stats_Section'
import React from 'react'

export default function about() {
  return (
    <div>
      <AboutStyleCom title="ABOUT US" />
        <Chairman_Speech/>
        <Stats_Section/>
        <Message_From_CEO/>
        <BUSINESS_AREAS_ANDCLASSIFICATIONS/>
        <BackgroundSection/>
        <Footer/>
    </div>
  )
}
