import AboutStyleCom from '@/components/About/AboutStyleCom/AboutStyleCom'
import Clients_STYLE from '@/components/Clients_STYLE/Clients_STYLE'
import BackgroundSection from '@/components/Home_Page/BackgroundSection/BackgroundSection'
import Footer from '@/components/Home_Page/Footer/Footer'
import React from 'react'
export default function Clients() {
  return (
    <div>
      <AboutStyleCom title="CLIENTS" />

      <Clients_STYLE/>
        
      <BackgroundSection />
      <Footer/>

    </div>
  )
}
