import AboutStyleCom from '@/components/About/AboutStyleCom/AboutStyleCom'
import BackgroundSection from '@/components/Home_Page/BackgroundSection/BackgroundSection'
import Footer from '@/components/Home_Page/Footer/Footer'
import ALL_Submenu_contact from '@/components/Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact'
import PROJECTS_MANAGEMENT_styl from '@/components/Services/Pages/ELECTRICAL_SYSTEMS/PROJECTS_MANAGEMENT_styl'
import Services_Page_Tabs from '@/components/Services/Pages/Services_Page_Tabs/Services_Page_Tabs'
import React from 'react'

export default function ELECTRICAL_SYSTEMS() {
  return (
    <div>
      <AboutStyleCom title="ELECTRICAL SYSTEMS" />
      <PROJECTS_MANAGEMENT_styl/>
      <BackgroundSection/>
<div className="sm:block md:hidden ">
  <Services_Page_Tabs />
  <ALL_Submenu_contact />
</div>

      <Footer/>

    </div>
  )
}
