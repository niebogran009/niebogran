import AboutStyleCom from '@/components/About/AboutStyleCom/AboutStyleCom'
import BackgroundSection from '@/components/Home_Page/BackgroundSection/BackgroundSection'
import Footer from '@/components/Home_Page/Footer/Footer'
import ALL_Submenu_contact from '@/components/Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact'
import Services_Page_Tabs from '@/components/Services/Pages/Services_Page_Tabs/Services_Page_Tabs'
import ServicesMenu_STYLE from '@/components/ServicesMenu_STYLE/ServicesMenu_STYLE'
import React from 'react'

export default function PROJECTS_MANAGEMENT() {
  return (
    <div>
        <AboutStyleCom title="PROJECTS MANAGEMENT" />
   
        <ServicesMenu_STYLE />
        
      <BackgroundSection />

      <div className="sm:block md:hidden">
  <Services_Page_Tabs />
  <ALL_Submenu_contact />
</div>
      <Footer/>

      {/* page Compleate */}
    </div>
  )
}
