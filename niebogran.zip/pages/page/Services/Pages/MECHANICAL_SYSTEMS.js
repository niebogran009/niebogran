import AboutStyleCom from '@/components/About/AboutStyleCom/AboutStyleCom'
import BackgroundSection from '@/components/Home_Page/BackgroundSection/BackgroundSection'
import Footer from '@/components/Home_Page/Footer/Footer'
import MECHANICAL_SYSTEMS_STYLE from '@/components/MECHANICAL_SYSTEMS_STYLE/MECHANICAL_SYSTEMS_STYLE'
import ALL_Submenu_contact from '@/components/Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact'
import Services_Page_Tabs from '@/components/Services/Pages/Services_Page_Tabs/Services_Page_Tabs'
import React from 'react'

export default function MECHANICAL_SYSTEMS() {
  return (
    <div>
     <AboutStyleCom title="MECHANICAL SYSTEMS" />
   
     <MECHANICAL_SYSTEMS_STYLE/>
 <BackgroundSection />

 <div className='sm:block md:hidden'> 
        <Services_Page_Tabs />
        <ALL_Submenu_contact/>
 
 </div>
 <Footer/>

    </div>
  )
}
