import AboutStyleCom from '@/components/About/AboutStyleCom/AboutStyleCom'
import BackgroundSection from '@/components/Home_Page/BackgroundSection/BackgroundSection'
import Footer from '@/components/Home_Page/Footer/Footer'
import Services_Niebogran_Services from '@/components/Services/Services_Niebogran_Services'
import React from 'react'

export default function Services() {
  return (
    <div>
      
      <AboutStyleCom title="SERVICES"/>
      <Services_Niebogran_Services/>
      <BackgroundSection/>
      <Footer/>
    </div>
  )
}
