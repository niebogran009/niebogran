import AboutStyleCom from '@/components/About/AboutStyleCom/AboutStyleCom'
import Electrical_Works_STYLE from '@/components/Electrical_Works_STYLE/Electrical_Works_STYLE'
import BackgroundSection from '@/components/Home_Page/BackgroundSection/BackgroundSection'
import Footer from '@/components/Home_Page/Footer/Footer'
import Link_Pages_Projects from '@/components/Link_Pages_Projects/Link_Pages_Projects'
import ALL_Submenu_contact from '@/components/Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact'
import React from 'react'

export default function Electrical_Works() {
  return (
    <div>
      <AboutStyleCom title="ELECTRICAL WORKS" />

      <Electrical_Works_STYLE />

      <BackgroundSection />




      <div className='sm:block md:hidden'>
        <Link_Pages_Projects />
        <ALL_Submenu_contact />
      </div>

      <Footer />

    </div>
  )
}
