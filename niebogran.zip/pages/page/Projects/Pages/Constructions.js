import AboutStyleCom from '@/components/About/AboutStyleCom/AboutStyleCom'
import Constructions_style from '@/components/Constructions_style/Constructions_style'
import BackgroundSection from '@/components/Home_Page/BackgroundSection/BackgroundSection'
import Footer from '@/components/Home_Page/Footer/Footer'
import Link_Pages_Projects from '@/components/Link_Pages_Projects/Link_Pages_Projects'
import ALL_Submenu_contact from '@/components/Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact'
import React from 'react'

export default function Constructions() {
  return (
    <div>
      <AboutStyleCom title="CONSTRUCTIONS" />


      <Constructions_style />

      <BackgroundSection />



      
      <div className='sm:block md:hidden'>
        <Link_Pages_Projects />
        <ALL_Submenu_contact />
      </div>





      <Footer />

    </div>
  )
}
