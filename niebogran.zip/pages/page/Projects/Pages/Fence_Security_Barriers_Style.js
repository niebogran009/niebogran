import AboutStyleCom from '@/components/About/AboutStyleCom/AboutStyleCom'
import Fence_Security_Barriers_Style from '@/components/Fence_Security_Barriers_Style/Fence_Security_Barriers_Style'
import BackgroundSection from '@/components/Home_Page/BackgroundSection/BackgroundSection'
import Footer from '@/components/Home_Page/Footer/Footer'
import Link_Pages_Projects from '@/components/Link_Pages_Projects/Link_Pages_Projects'
import ALL_Submenu_contact from '@/components/Services/Pages/ELECTRICAL_SYSTEMS/ALL_Submenu_contact/ALL_Submenu_contact'
import React from 'react'

export default function Fence_Security_Barriers() {
  return (
    <div>
      <AboutStyleCom title="Fence & Security Barriers" />



      <Fence_Security_Barriers_Style />
      <BackgroundSection />



      
      <div className='sm:block md:hidden'>
        <Link_Pages_Projects />
        <ALL_Submenu_contact />
      </div>





      <Footer />

    </div>
  )
}
