import AboutStyleCom from '@/components/About/AboutStyleCom/AboutStyleCom'
import BackgroundSection from '@/components/Home_Page/BackgroundSection/BackgroundSection'
import Footer from '@/components/Home_Page/Footer/Footer'
import Projects_main_style from '@/components/Projects_main_style/Projects_main_style'
import React from 'react'

export default function Projects_Page() {
  return (
    <div>
        <div>
      <AboutStyleCom title="PROJECTS" />

      <Projects_main_style/>
      <BackgroundSection/>
      <Footer/>

    </div>
    </div>
  )
}
