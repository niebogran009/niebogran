import Carousel_Image from '@/components/Carousel/Carousel_Image'
import BackgroundSection from '@/components/Home_Page/BackgroundSection/BackgroundSection'
import Chairman_Speech from '@/components/Home_Page/Chairman_Speech/Chairman_Speech'
import Footer from '@/components/Home_Page/Footer/Footer'
import Niebogran_Clients from '@/components/Home_Page/Niebogran_Clients/Niebogran_Clients'
import Niebogran_Projects from '@/components/Home_Page/Niebogran_Projects/Niebogran_Projects'
import Niebogran_Service from '@/components/Home_Page/Niebogran_Service/Niebogran_Service'
import Stats_Section from '@/components/Home_Page/Stats_Section/Stats_Section'
import React from 'react'

export default function index() {
  return (
    <div>
      <Carousel_Image/>
      <Chairman_Speech/>
      <Stats_Section />

        <Niebogran_Projects />

          <BackgroundSection/>

       <Niebogran_Service/>

       <Niebogran_Clients/>
       <Footer/>
    </div>
  )
};