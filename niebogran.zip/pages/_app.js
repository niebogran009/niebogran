import "/styles/globals.css";  // This will import the styles
import { useEffect } from "react";
import Top_Navbar from "@/components/Navbar/topNavbar/Top_Navbar";
import Mobile_Menu from "@/components/Navbar/Mobile_Menu";
import Button_Top_scrol_Bar from "@/components/Button_Top_scrol/Button_Top_scrol_Bar";
import Md_Navbar from "@/components/Navbar/Md_Navbar";
import Sm_Navbar from "@/components/Navbar/topNavbar/Sm_Navbar";
import "../styles/globals.css";

function MyApp({ Component, pageProps }) {
  useEffect(() => {
    // You can add any code to run after the component is mounted, if needed
  }, []);

  return (
    <>
    <Top_Navbar/>
    <div  className="sm:block md:hidden">
    <Mobile_Menu/>
    <Sm_Navbar/>
    </div>
      <Md_Navbar />
      <Button_Top_scrol_Bar/>
      <Component {...pageProps} />
    </>
  );
}

export default MyApp;
