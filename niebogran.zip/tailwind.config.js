module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
    "./styles/**/*.{css,scss}", // Ensure your styles are included
  ],
  theme: {
    extend: {
      colors: {
        primary: "#0e2f4d", // Your custom color here
      },
    },
  },
  plugins: [],
};
